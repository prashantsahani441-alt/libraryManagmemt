
# Library Management System

## Features
- Add Book
- View Books
- Update Book
- Delete Book

## Run Project
mvn spring-boot:run

## API Endpoints
GET    /books
POST   /books
PUT    /books/{id}
DELETE /books/{id}
